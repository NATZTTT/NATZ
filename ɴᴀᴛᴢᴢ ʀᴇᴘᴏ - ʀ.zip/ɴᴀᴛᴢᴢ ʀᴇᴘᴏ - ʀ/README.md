
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/NATZTTT/ubot
```
```
kalo munculnya "fatal : git clonexxxx"
ketik "sudo rm -r ubot
```
```
kalo udah masukin cmd git clone lagi
```
```
cd ubot && screen -S ubot 
```
```
bash installnode.sh && apt install python3.10-venv
```
```
python3 -m venv ubot && source ubot/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
